﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.P
{
    /// <summary>
    /// Логика взаимодействия для All_UserInterestGroups_Page.xaml
    /// </summary>
    public partial class All_UserInterestGroups_Page :Page
    {
        public UserInterestGroup _userInterestGroup = new();
        //bool IsEdit = false;
        public All_UserInterestGroups_Page (UserInterestGroup? userInterestGroup = null)
        {
            //if(userInterestGroup != null)
            //{
            //    _userInterestGroup = userInterestGroup;
            //    IsEdit = true;
            //}
            InitializeComponent();
        }
    }
}
