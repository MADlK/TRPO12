﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.P
{
    /// <summary>
    /// Логика взаимодействия для StudentFormPage.xaml
    /// </summary>
    public partial class StudentFormPage : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged ([CallerMemberName] string? propName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
        public RoleService _roleservice { get; set; } = new();
        public StudentSirvice _service { get; set; } = new();
        private Student _student = new();
        public Student Student
        {
            get => _student;
            set
            {
                _student = value;
                OnPropertyChanged();
                
            }
        }
        bool isEdit = false;


        public StudentFormPage (Student? _editStudent = null)
        {
            InitializeComponent();
            if (_editStudent != null)
            {
                Student = _editStudent;
                isEdit = true;
            }
            if (Student.Profile == null)
                Student.Profile = new();
        }

        private void save (object sender, RoutedEventArgs e)
        {
            
            if (Validation.GetHasError(UName) || Validation.GetHasError(LogTB) || Validation.GetHasError(EmailTB) || Validation.GetHasError(PassTB) || Validation.GetHasError(RegTB))
            {
                MessageBox.Show("Если есть ошибка создать не получится");
                return;
            }
            
            

                if (isEdit)
                    _service.Commit();
                else
                    _service.Add(_student);
                NavigationService.GoBack();

            
            
           



        }
        private void back (object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }


    }
}
