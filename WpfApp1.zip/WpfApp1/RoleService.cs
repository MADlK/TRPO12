﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.DB;

namespace WpfApp1
{
    public class RoleService
    {
        private readonly DBC _db = BaseDbService.Instance.Context;
        public ObservableCollection<Role> Roles { get; set; } = new();
        public RoleService ()
        {
            GetAll();
        }
        public void Add (Role role)
        {
            var _role = new Role
            {
                Title = role.Title,
                

            };
            _db.Add<Role>(_role);
            Commit();
            Roles.Add(_role);
        }
        public int Commit () => _db.SaveChanges();
        public void GetAll ()
        {
            var roles = _db.Roles.ToList();
            Roles.Clear();
            foreach (var role in roles)
            {
                Roles.Add(role);
            }
        }
      
    }
}
